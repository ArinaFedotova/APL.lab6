
namespace FileOperations
{
    public interface IInitialAge
    {
        Dictionary<int, int> GetDataInitAge();
    }
}